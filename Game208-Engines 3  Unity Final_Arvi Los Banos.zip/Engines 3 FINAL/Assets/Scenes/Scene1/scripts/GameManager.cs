﻿using UnityEngine;
using UnityEngine.SceneManagement; // required for SceneManager

public class GameManager : MonoBehaviour
{
    private static GameManager instance;
    public static GameManager MyInstance
    {
        get
        {
            if (instance == null)
            {
                instance = FindObjectOfType<GameManager>();

                if (instance == null)
                {
                    Debug.LogError("No GameManager found in the scene!");
                }
            }
            return instance;
        }
    }

    [Header("Memory Tracking")]
    [SerializeField] private int keysCollected = 0;
    [SerializeField] private int victoryCondition = 1; // total required to finish

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else if (instance != this)
        {
            Destroy(gameObject);
        }
    }

    private void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    private void OnDisable()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        // Reset memory count for the new level
        keysCollected = 0;

        // Hide victory message
        UIManager.MyInstance.HideVictoryCondition();

        // Reset the UI text
        UIManager.MyInstance.UpdateKeyUI(keysCollected, victoryCondition);
    }


    private void Start()
    {
        keysCollected = 0;
        UIManager.MyInstance.UpdateKeyUI(keysCollected, victoryCondition);
    }

    public void AddKeys(int keyAmount)
    {
        keysCollected += keyAmount;
        UIManager.MyInstance.UpdateKeyUI(keysCollected, victoryCondition);
        Debug.Log($"Keys collected: {keysCollected}");
    }

    public void Finish()
    {
        if (keysCollected >= victoryCondition)
        {
            keysCollected = 0;
            // Get the index of the current scene
            int currentSceneIndex = SceneManager.GetActiveScene().buildIndex;

                // Load the next scene in Build Settings
                int nextSceneIndex = currentSceneIndex + 1;


                // Check if the next scene exists
                if (nextSceneIndex < SceneManager.sceneCountInBuildSettings)
                {
                    SceneManager.LoadScene(nextSceneIndex);
                }
                else
                {
                    Debug.Log("No more levels — game complete!");
                    // You could load a “You Win” screen here instead
                    // SceneManager.LoadScene("WinScreen");
                }

        }
        else
        {
            UIManager.MyInstance.ShowVictoryCondition(keysCollected, victoryCondition);
        }
    }
}
