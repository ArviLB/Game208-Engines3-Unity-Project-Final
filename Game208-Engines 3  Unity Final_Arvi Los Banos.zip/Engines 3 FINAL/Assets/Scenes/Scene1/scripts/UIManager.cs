using UnityEngine;
using TMPro;

public class UIManager : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI txtKeys;
    [SerializeField] private TextMeshProUGUI txtVictoryCondition;
    [SerializeField] private GameObject victoryCondition;

    private static UIManager instance;
    public static UIManager MyInstance
    {
        get
        {
            if (instance == null)
            {
                instance = FindObjectOfType<UIManager>();
                if (instance == null)
                {
                    Debug.LogError("No UIManager found in the scene!");
                }
            }
            return instance;
        }
    }

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else if (instance != this)
        {
            Destroy(gameObject);
        }
    }

    public void UpdateKeyUI(int _keys, int _victoryCondition)
    {
        if (txtKeys != null)
            txtKeys.text = $"Memories: {_keys}/{_victoryCondition}";
    }

    public void ShowVictoryCondition(int _keys, int _victoryCondition)
    {
        if (victoryCondition != null)
            victoryCondition.SetActive(true);

        if (txtVictoryCondition != null)
            txtVictoryCondition.text = $"You do not have enough memories to move on...";
    }

    public void HideVictoryCondition()
    {
        if (victoryCondition != null)
            victoryCondition.SetActive(false);
    }
}
