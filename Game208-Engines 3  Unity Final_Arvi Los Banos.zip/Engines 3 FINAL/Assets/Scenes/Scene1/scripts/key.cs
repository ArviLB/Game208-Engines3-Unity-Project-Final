using UnityEngine;

public class key : Collectable
{
    [SerializeField] private int numKeys = 1;

    protected override void Collected()
    {
        if (GameManager.MyInstance != null)
        {
            GameManager.MyInstance.AddKeys(numKeys);
        }

        // You can add sound, animation, or VFX here if needed
        Destroy(gameObject);
    }
}
