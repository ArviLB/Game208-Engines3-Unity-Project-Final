using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Cinemachine;

public class CameraZoom : MonoBehaviour
{
    [SerializeField] private CinemachineCamera cam;
    [SerializeField] private PlayerMovement player; // Reference to your player movement script

    [Header("Zoom Settings")]
    [SerializeField] private float zoomedInSize = 3f;
    [SerializeField] private float zoomedOutSize = 8f;
    [SerializeField] private float smoothTime = 0.25f;
    [SerializeField] private KeyCode toggleKey = KeyCode.Z;

    private float targetZoom;
    private float velocity = 0f;
    private bool isZoomedIn = false;

    void Start()
    {
        // Start zoomed out by default (can change this if you want)
        targetZoom = zoomedOutSize;
        cam.Lens.OrthographicSize = targetZoom;
    }

    void Update()
    {
        // Automatically zoom in when player starts moving
        if (player.IsMoving)
        {
            isZoomedIn = true;
            targetZoom = zoomedInSize;
        }
        else
        {
            // Allow manual toggle only when player is NOT moving
            if (Input.GetKeyDown(toggleKey))
            {
                isZoomedIn = !isZoomedIn;
                targetZoom = isZoomedIn ? zoomedInSize : zoomedOutSize;
            }
        }

        // Smooth transition
        cam.Lens.OrthographicSize = Mathf.SmoothDamp(
            cam.Lens.OrthographicSize,
            targetZoom,
            ref velocity,
            smoothTime
        );
    }
}
