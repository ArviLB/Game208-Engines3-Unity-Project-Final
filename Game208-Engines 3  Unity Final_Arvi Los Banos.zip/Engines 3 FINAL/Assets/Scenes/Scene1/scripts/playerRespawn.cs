using UnityEngine;

public class PlayerRespawn : MonoBehaviour
{
    [SerializeField] private Transform respawnPoint; // Assign PlayerStart in Inspector
    [SerializeField] private float respawnDelay = 0.5f;

    private bool isRespawning = false;

    public void Respawn()
    {
        if (!isRespawning)
            StartCoroutine(RespawnRoutine());
    }

    private System.Collections.IEnumerator RespawnRoutine()
    {
        isRespawning = true;

        // Optional: add death animation or sound here
        yield return new WaitForSeconds(respawnDelay);

        transform.position = respawnPoint.position;
        // Optional: reset velocity if using Rigidbody2D
        if (TryGetComponent<Rigidbody2D>(out var rb))
        {
            rb.linearVelocity = Vector2.zero;
        }

        isRespawning = false;
    }
}
