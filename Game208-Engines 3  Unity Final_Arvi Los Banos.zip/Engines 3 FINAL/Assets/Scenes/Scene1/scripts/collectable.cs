using UnityEngine;

public class Collectable : MonoBehaviour
{
    protected virtual void Collected()
    {
        // This will be overridden by child classes (e.g., key)
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            Collected();
        }
    }
}
